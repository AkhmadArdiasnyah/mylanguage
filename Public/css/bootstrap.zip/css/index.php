<?php
$absolute_path = realpath($_SERVER["DOCUMENT_ROOT"])."/BasketPedia";
require "$absolute_path/app/core/MVC_model.php";
require "$absolute_path/app/controller/Super_Default_method.php";